package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private Button btnHasil;
    private TextView tvHasil;
    private EditText etNama, etNIM, etIPK;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnHasil = findViewById(R.id.btn_hasil);
        tvHasil = findViewById(R.id.tv_hasil);
        etNama = findViewById(R.id.et_nama);
        etNIM = findViewById(R.id.et_nim);
        etIPK = findViewById(R.id.et_ipk);

        btnHasil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int angka = 0;
                String angka1 = etIPK.getText().toString();
                angka=Integer.parseInt(angka1);

                if ((angka >3.66) && (angka<=4.00)){
                   tvHasil.setText("A");
                }
                else if ((angka >3.33) && (angka<=3.66)){
                    tvHasil.setText("A-");
                }
                else if ((angka >3.00) && (angka<=3.33)){
                    tvHasil.setText("B+");
                }
                else if ((angka >2.66) && (angka<=3.00)){
                    tvHasil.setText("B");
                }
                else if ((angka >2.33) && (angka<=2.66)){
                    tvHasil.setText("B-");
                }
                else if ((angka >2.00) && (angka<=2.33)){
                    tvHasil.setText("C+");
                }
                else if ((angka >1.66) && (angka<=2.00)){
                    tvHasil.setText("C");
                }
                else if ((angka >1.33) && (angka<=1.66)){
                    tvHasil.setText("C-");
                }
                else if ((angka >1.00) && (angka<=1.33)){
                    tvHasil.setText("D+");
                }
                else if (angka == 1.00){
                    tvHasil.setText("D");
                }
                else {
                    tvHasil.setText("Tidak Lulus");
                }
            }
        });
    }
}